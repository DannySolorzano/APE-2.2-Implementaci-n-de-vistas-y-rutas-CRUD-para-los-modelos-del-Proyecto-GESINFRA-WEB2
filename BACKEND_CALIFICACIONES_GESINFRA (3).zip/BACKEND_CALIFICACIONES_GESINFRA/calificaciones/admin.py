from django.contrib import admin
from django.utils.html import format_html
from .models import RegistroCalificacion

@admin.register(RegistroCalificacion)
class RegistroCalificacionAdmin(admin.ModelAdmin):
    
    list_display = (
        'asignatura', 
        'nota_obtenida_coloreada', 
        'fecha_evaluacion', 
        'usuario_registro',
        'estado_calificacion'
    )
    
    list_filter = ('asignatura', 'fecha_evaluacion', 'usuario_registro')
    search_fields = ('asignatura', 'usuario_registro__username')
    date_hierarchy = 'fecha_evaluacion'
    
    fieldsets = (
        ('Información Académica', {
            'fields': ('asignatura', 'nota_obtenida', 'fecha_evaluacion'),
            'description': 'Escala: 0.00 a 10.00'
        }),
        ('Información del Registro', {
            'fields': ('usuario_registro',)
        }),
    )
    
    def nota_obtenida_coloreada(self, obj):
        if obj.nota_obtenida >= 6:
            color = 'green'
        else:
            color = 'red'
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}/10</span>',
            color,
            obj.nota_obtenida
        )
    nota_obtenida_coloreada.short_description = 'Nota (0-10)'
    
    def estado_calificacion(self, obj):
        estado = obj.get_estado_calificacion()
        color = 'green' if estado == "Aprobado" else 'red'
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            estado
        )
    estado_calificacion.short_description = 'Estado'
    
    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.usuario_registro = request.user
        super().save_model(request, obj, form, change)