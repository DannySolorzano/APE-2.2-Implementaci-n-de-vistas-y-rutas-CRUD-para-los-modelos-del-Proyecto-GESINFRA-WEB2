from django import forms
from .models import RegistroCalificacion

class RegistroCalificacionForm(forms.ModelForm):
    
    class Meta:
        model = RegistroCalificacion
        fields = ['asignatura', 'nota_obtenida', 'fecha_evaluacion']
        
        widgets = {
            'asignatura': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: Matemáticas I',
                'required': True
            }),
            'nota_obtenida': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0',
                'max': '10',
                'placeholder': '0.00 a 10.00',
                'required': True
            }),
            'fecha_evaluacion': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date',
                'required': True
            }),
        }
        
        labels = {
            'asignatura': 'Asignatura',
            'nota_obtenida': 'Nota Obtenida (0-10)',
            'fecha_evaluacion': 'Fecha de Evaluación',
        }
        
        help_texts = {
            'nota_obtenida': 'La nota debe estar entre 0.00 y 10.00',
        }
    
    def clean_nota_obtenida(self):
        nota = self.cleaned_data.get('nota_obtenida')
        if nota is None:
            raise forms.ValidationError("La nota es requerida")
        if not (0 <= float(nota) <= 10):
            raise forms.ValidationError("La nota debe estar entre 0.00 y 10.00")
        return nota