from django.apps import AppConfig


class CalificacionesConfig(AppConfig):
    name = 'calificaciones'
