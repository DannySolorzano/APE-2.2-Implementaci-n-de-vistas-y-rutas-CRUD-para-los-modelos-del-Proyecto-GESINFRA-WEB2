from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import RegistroCalificacion
from .forms import RegistroCalificacionForm
from django.contrib.auth.models import User

@login_required
def listar_calificaciones(request):
    calificaciones = RegistroCalificacion.objects.all().order_by('-fecha_evaluacion')
    
    total_calificaciones = calificaciones.count()
    aprobados = calificaciones.filter(nota_obtenida__gte=6).count()
    desaprobados = total_calificaciones - aprobados
    
    context = {
        'calificaciones': calificaciones,
        'total_calificaciones': total_calificaciones,
        'aprobados': aprobados,
        'desaprobados': desaprobados,
        'titulo': 'Listado de Calificaciones'
    }
    
    return render(request, 'calificaciones/listar.html', context)

@login_required
def registrar_calificacion(request):
    if request.method == 'POST':
        form = RegistroCalificacionForm(request.POST)
        
        if form.is_valid():
            nueva_calificacion = form.save(commit=False)
            nueva_calificacion.usuario_registro = request.user
            nueva_calificacion.save()
            
            messages.success(
                request, 
                f'✅ Calificación registrada: {nueva_calificacion.asignatura} - {nueva_calificacion.nota_obtenida}/10'
            )
            
            return redirect('listar_calificaciones')
        else:
            messages.error(request, '❌ Error en el formulario.')
    else:
        form = RegistroCalificacionForm()
    
    context = {
        'form': form,
        'titulo': 'Registrar Nueva Calificación'
    }
    
    return render(request, 'calificaciones/registrar.html', context)

@login_required
def detalle_calificacion(request, id):
    calificacion = get_object_or_404(RegistroCalificacion, id=id)
    
    context = {
        'calificacion': calificacion,
        'titulo': f'Detalle: {calificacion.asignatura}'
    }
    
    return render(request, 'calificaciones/detalle.html', context)

@login_required
def estadisticas(request):
    from django.db.models import Count, Avg, Max, Min
    
    calificaciones_por_usuario = User.objects.annotate(
        total_calificaciones=Count('calificaciones_registradas')
    ).filter(total_calificaciones__gt=0)
    
    promedio_general = RegistroCalificacion.objects.aggregate(
        promedio=Avg('nota_obtenida')
    )
    
    por_asignatura = RegistroCalificacion.objects.values('asignatura').annotate(
        total=Count('id'),
        promedio=Avg('nota_obtenida'),
        maxima=Max('nota_obtenida'),
        minima=Min('nota_obtenida')
    ).order_by('-total')
    
    context = {
        'calificaciones_por_usuario': calificaciones_por_usuario,
        'promedio_general': promedio_general['promedio'] or 0,
        'por_asignatura': por_asignatura,
        'titulo': 'Estadísticas de Calificaciones'
    }
    
    return render(request, 'calificaciones/estadisticas.html', context)