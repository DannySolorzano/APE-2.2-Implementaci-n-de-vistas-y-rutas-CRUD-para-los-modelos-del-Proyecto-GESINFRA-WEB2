from django.db import models
from django.contrib.auth.models import User

class RegistroCalificacion(models.Model):
    """
    Modelo para el registro de calificaciones.
    ESCALA: 0 a 10 puntos
    """
    
    asignatura = models.CharField(
        max_length=100,
        verbose_name="Asignatura",
        help_text="Nombre de la asignatura evaluada"
    )
    
    nota_obtenida = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        verbose_name="Nota Obtenida",
        help_text="Ingrese la nota entre 0.00 y 10.00"
    )
    
    fecha_evaluacion = models.DateField(
        verbose_name="Fecha de Evaluación",
        help_text="Fecha en que se realizó la evaluación"
    )
    
    usuario_registro = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name="Usuario que registra",
        related_name="calificaciones_registradas"
    )
    
    fecha_registro = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Fecha de Registro"
    )
    
    class Meta:
        verbose_name = "Registro de Calificación"
        verbose_name_plural = "Registros de Calificaciones"
        ordering = ['-fecha_evaluacion']
    
    def __str__(self):
        return f"{self.asignatura} - {self.nota_obtenida}/10"
    
    def get_estado_calificacion(self):
        if self.nota_obtenida >=7:
            return "Aprobado"
        else:
            return "Desaprobado"