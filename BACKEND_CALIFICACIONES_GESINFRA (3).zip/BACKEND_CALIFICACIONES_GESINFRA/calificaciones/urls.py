from django.urls import path
from . import views

urlpatterns = [
    # REQUERIDO: /calificaciones/ - Listar calificaciones
    path('', views.listar_calificaciones, name='listar_calificaciones'),
    
    # REQUERIDO: /calificaciones/registrar/ - Registrar nueva calificación
    path('registrar/', views.registrar_calificacion, name='registrar_calificacion'),
    
    # Opcional: Detalle de calificación
    path('detalle/<int:id>/', views.detalle_calificacion, name='detalle_calificacion'),
    
    # Opcional: Estadísticas
    path('estadisticas/', views.estadisticas, name='estadisticas'),
]